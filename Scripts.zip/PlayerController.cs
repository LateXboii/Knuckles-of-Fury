﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

    private bool attacking = false;
    public float walkSpeed = 10F;
    public float runSpeed = 18F;
    bool facingright = true;
    private bool running = false;
  



    public float health;
    Animator anim;
    Rigidbody2D rigidbody2D;



    // Update is called once per frame
    void Start()
    {
        anim = GetComponent<Animator>();
        rigidbody2D = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        float move = Input.GetAxis("Horizontal");


        if (move != 0F)
        {
            float speed;
            if (Input.GetKey(KeyCode.LeftShift))
            {
                speed = runSpeed;
                anim.SetBool("Running", true);
            }
            else if (Input.GetKeyUp(KeyCode.LeftShift))
            {
                speed = walkSpeed;
                anim.SetBool("Running", false);
            }
            else
            {
                speed = walkSpeed;
                anim.SetBool("Walking", true);
            }

            PlayerMovement(move,speed);
          
        }
        else if (move == 0)
        {
            anim.SetBool("Walking", false);
        }


        //Debug.Log(move);
        anim.SetFloat("Speed", Mathf.Abs(move));

        if (move > 0 && !facingright)
            Flip();
        else if (move < 0 && facingright)
            Flip();


        if (Input.GetKeyDown(KeyCode.A))
        {
            anim.SetBool("Hitting", true);
            Debug.Log("Hyökätään");
            attacking = true;

        }


        if (Input.GetKeyDown(KeyCode.Z))
        {
            anim.SetBool("Kicking", true);
            Debug.Log("Potkitaan");
            attacking = true;

        }

        
    }

    void OnTriggerEnter2D(Collider2D coll)
    {
        if (coll.gameObject.tag == "Enemy")
        {
            Debug.Log("Trigger tuli");
        }
    }

    void TakeSomeDamage(int damage)
    {
        health -= damage;
        if (health <= 0)
        {
            Debug.Log("Dead)");
        }
    }

    void Flip()
    {
        facingright = !facingright;
        Vector3 thescale = transform.localScale;
        thescale.x *= -1;
        transform.localScale = thescale;

    }

    void PlayerMovement(float direction, float speed)
    {
        transform.Translate(Vector3.right * (speed * direction) * Time.deltaTime);
        //rigidbody2D.AddForce(new Vector2(direction * maxSpeed, 0), ForceMode2D.Force);
        Debug.Log(speed);
  

    }
    void AnimationPlayed()
    {
        anim.SetBool("Hitting", false);
        anim.SetBool("Kicking", false);
       // anim.SetBool("Running", false);
    }

   
}
